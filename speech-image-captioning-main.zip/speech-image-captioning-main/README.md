# speech-image-captioning
Voice-triggered real-time image captioning system using MLP for keyword spotting, CLIP for visual understanding, GPT-2 for caption generation, and Tacotron TTS for audio feedback. Built for assistive tech applications like helping visually impaired users.
